import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.Scanner;
import java.util.Set;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by S_Hader on 12/2/2016.
 */


/*
    prb: stdInfo wasn't working, reolved by putting it in block of method can also be resolve
        by putting in some other blocks
        update: actually problem was that object can work in methods and we didn't use main or any
        other method to wrap out treeMap's object
        (solved).

    prb: when keyId is same it will write only one value, at last the last value will be written,
        resolved by changing keyId value.
 */
public class Write {
    static short sheetNo = 1;


    public boolean isNumeric(String s) {
        return s.matches("[-+]?\\d*\\.?\\d+");
    }

    public void write (String fName) {
        // blank workbook , workbook = wb, in code
        XSSFWorkbook wb = new XSSFWorkbook();

        // blank spread sheet, newSheet in code
        XSSFSheet newSheet = wb.createSheet("Sheet" + sheetNo);
        sheetNo++;

        // row object, row in code
        // cell, cell in code
        XSSFRow row;

        // data needs to be written
        // student info = stdInfo in code
        // Map is interface <K, V>
        // k= type of key maintained,   v= type of maped value
        Map < String, Object[] > stdInfo = new TreeMap < String, Object[] >();

        Scanner reader = null;
        try {
            reader = new Scanner(new File("datas.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        int i=0;
        int j=0;

        while (reader.hasNextLine()) {
//                System.out.println(reader.nextLine());
//            System.out.println(reader.next() + " " + reader.nextLine() + " " + reader.nextLine());
            String num = reader.nextLine();
            String txt = reader.nextLine();
            System.out.println(num + " " + txt);
            stdInfo.put(" " + i + j, new Object[]{
                    num, txt
            });

            while(!reader.nextLine().isEmpty()) {
                System.out.println(num + " " + txt);
                stdInfo.put(" " + i + j + 1, new Object[]{
                        num, txt
                });
                j++;
            }
            i++;
        }


        Set < String > keyId = stdInfo.keySet();
        int rowId = 1;
        for(String key : keyId) {
            // for each row id it'll create new row and will increment in rowId
            row = newSheet.createRow(rowId++);
            Object [] objArr = stdInfo.get(key);
            int cellId = 0;
            for(Object obj : objArr) {
                Cell cell = row.createCell(cellId++);
                cell.setCellValue((String)obj);
            }
        }

        // write this work book in excel file
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(
                    new File(fName + ".xlsx"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            wb.write(out);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        boolean delete = (new File("datas.txt")).delete();
        System.out.println("Written successfully");

    }
}
