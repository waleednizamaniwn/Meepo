import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.Iterator;

/**
 * Created by S_Hader on 12/2/2016.
 */
public class Read {
    static XSSFRow row;


    public void read(String fName) {
        FileInputStream inp = null;
        try {
            inp = new FileInputStream(
                    new File(fName));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        XSSFWorkbook wb = null;
        try {
            wb = new XSSFWorkbook(inp);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            FileWriter fileWriter = new FileWriter(new File("datas.txt"), false);
            PrintWriter output = new PrintWriter(fileWriter);

        XSSFSheet newSheet = wb.getSheetAt(0);
        Iterator<Row> rowIterator = newSheet.iterator();
        while (rowIterator.hasNext()) {
            row = (XSSFRow) rowIterator.next();
            Iterator <Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext())
            {
                Cell cell = cellIterator.next();
                switch (cell.getCellType()) {
                    case Cell.CELL_TYPE_NUMERIC:
                        //System.out.print(cell.getNumericCellValue() + "\t");
                        int num = (int)cell.getNumericCellValue();
                        output.println(num);
                        break;
                    case Cell.CELL_TYPE_STRING:
                        String string1 = cell.getStringCellValue();
                        for(String str: string1.split("\\.")) {
                            output.println(str);
                        }
                        break;
                }
            }
            output.println();

            //System.out.println();
        }
        output.close();
        try {
            inp.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
