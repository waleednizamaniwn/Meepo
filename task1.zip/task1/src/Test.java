/**
 * Created by Computer on 12/3/2016.
 */
public class Test {
        public static void main(String[] args) {
            String fName = "EnterData.xlsx";
            Read reader = new Read();
            reader.read(fName);
            Write writer = new Write();
            writer.write("fresh");
        }
}
