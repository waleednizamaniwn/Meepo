/**
 * Created by S_Hader on 12/4/2016.
 */
// interface is designed by Waleed
// vlause are written by Hader

public class InterFace extends javax.swing.JFrame {

    public InterFace() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(290, 90));
        setPreferredSize(new java.awt.Dimension(800, 550));
        setSize(new java.awt.Dimension(800, 550));
        getContentPane().setLayout(null);

        jButton3.setText("Skip");
        getContentPane().add(jButton3);
        jButton3.setBounds(450, 430, 190, 40);

        jButton4.setText("Next Comment");
        getContentPane().add(jButton4);
        jButton4.setBounds(130, 430, 190, 40);

        getContentPane().add(jCheckBox1);
        jCheckBox1.setBounds(100, 210, 560, 23);
        jCheckBox1.setText("Accessibilty of teacher outside the class room");

        getContentPane().add(jCheckBox2);
        jCheckBox2.setBounds(100, 390, 560, 23);
        jCheckBox2.setText("Knowledge base/grip of the intructor over subject");

        getContentPane().add(jCheckBox3);
        jCheckBox3.setBounds(100, 360, 560, 23);
        jCheckBox3.setText("Instructor's ability to motivate you towards the module");

        getContentPane().add(jCheckBox4);
        jCheckBox4.setBounds(100, 330, 560, 23);
        jCheckBox4.setText("Instructor's ability to integrate contents of module with real-world");

        getContentPane().add(jCheckBox5);
        jCheckBox5.setBounds(100, 300, 560, 23);
        jCheckBox5.setText("Adherence to course outline?");

        getContentPane().add(jCheckBox6);
        jCheckBox6.setBounds(100, 270, 560, 23);
        jCheckBox6.setText("Instructor's concern regarding lab");

        getContentPane().add(jCheckBox7);
        jCheckBox7.setBounds(100, 240, 560, 23);
        jCheckBox7.setText("Your satisfaction level with the delivery metho of the instructor");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(50, 60, 660, 130);

        pack();
    }// </editor-fold>

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterFace().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration
}
