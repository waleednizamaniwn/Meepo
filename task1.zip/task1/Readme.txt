You need to provide an Excel file, the program will read the file and write it to a text file. After that it will read from that text file and write to another Excel sheet named "fresh.xlsx".

you may need to delete the already excisting "fresh.xlsx" file before running it again. 