package task2;

public class InterFace2 extends javax.swing.JFrame {

    public InterFace2() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jSlider1 = new javax.swing.JSlider();
        SubjectField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        PredicateField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        jRadioButton1.setText("jRadioButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(290, 90));
        setPreferredSize(new java.awt.Dimension(800, 550));
        setSize(new java.awt.Dimension(800, 550));
        getContentPane().setLayout(null);

        jButton3.setText("Skip Comment");
        jButton3.setToolTipText("Skip and go to the Next Comment");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(450, 430, 190, 40);

        jButton4.setText("Next Comment");
        jButton4.setToolTipText("Submit Response");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(130, 430, 190, 40);

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("How are you");
        jTextArea1.setToolTipText("");
        jScrollPane1.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(50, 60, 660, 130);

        jSlider1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jSlider1.setMajorTickSpacing(1);
        jSlider1.setMaximum(5);
        jSlider1.setMinimum(1);
        jSlider1.setMinorTickSpacing(1);
        jSlider1.setPaintLabels(true);
        jSlider1.setValue(1);
        jSlider1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jSlider1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider1StateChanged(evt);
            }
        });
        getContentPane().add(jSlider1);
        jSlider1.setBounds(100, 370, 580, 40);

        SubjectField.setEditable(false);
        SubjectField.setText("you");
        SubjectField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubjectFieldActionPerformed(evt);
            }
        });
        getContentPane().add(SubjectField);
        SubjectField.setBounds(180, 260, 310, 30);

        jLabel2.setText("Subject");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(80, 260, 60, 30);

        jLabel3.setText("Predicate");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(80, 300, 60, 30);

        PredicateField.setEditable(false);
        PredicateField.setText("How");
        PredicateField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PredicateFieldActionPerformed(evt);
            }
        });
        getContentPane().add(PredicateField);
        PredicateField.setBounds(180, 300, 310, 30);

        jLabel1.setText("Comment");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(50, 30, 70, 20);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SubjectFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubjectFieldActionPerformed
    }//GEN-LAST:event_SubjectFieldActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String subjects = "";
        String predicate = "";
        
        System.out.println("Score: " + this.jSlider1.getValue());
        
        // YOU CAN CHANGE THIS SENTENCE AND TEST
        String sentence = "The aeroplance was big";
        
        this.jTextArea1.setText(sentence);
        String [] realSentence = sentence.split(" ");
        
        boolean subCheck = false;
        boolean isCheck = false;
        String isString = "is";
        String toString = "to";
        
        System.out.println("\n\n Subjects:\n\n");
        
        // Subjects are mostly bofore these words
        String [] afterSub = {"am", "was", "is", "has", "will", "should", "could", "can","have","are",
        "need","needs","speak", "dont","does", "from"};
        String word = realSentence[0];
        String afterWord = realSentence[1];
        // ITerating from word to word looking for afterSubs!
        for(int i = 0 ; i < realSentence.length - 1 ; i++)
        {
            subCheck = false;
            word = realSentence[i];
            afterWord = realSentence[i+1];
            
            for(int j = 0 ; j < afterSub.length ; j++)
            {
                if (afterWord.equalsIgnoreCase(afterSub[j]) == true)  //If afterword is the after sub then the prceeding word is actually a subject!
                       subCheck = true;
                if (isString.equalsIgnoreCase(word) || toString.equalsIgnoreCase(word))
                       isCheck = true;
            }
            if (subCheck == true)  //  If it matches the word is the subject
                subjects= subjects + " " + word;
            if (isCheck == true)
                predicate = predicate + " " + afterWord;
        }
        this.SubjectField.setText(subjects);
        this.PredicateField.setText(afterWord);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jSlider1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider1StateChanged
        
    }//GEN-LAST:event_jSlider1StateChanged

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        System.out.println("Skipped");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void PredicateFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PredicateFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PredicateFieldActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterFace2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField PredicateField;
    private javax.swing.JTextField SubjectField;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
