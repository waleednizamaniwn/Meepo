Please Choose the naming convention as follows

Name your Second Project as "Project"
Name your Third Project as "Task2"

You should choose NetBeans as your IDE, as we couldn't get it to work with any other IDE.

