import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterFace extends javax.swing.JFrame {
    
    
    public InterFace() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        CommentArea = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(290, 90));
        setPreferredSize(new java.awt.Dimension(800, 550));
        setSize(new java.awt.Dimension(800, 550));
        getContentPane().setLayout(null);

        jButton3.setText("Skip Comment");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(450, 430, 190, 40);

        jButton4.setText("Next Comment");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(130, 430, 190, 40);
        jButton4.getAccessibleContext().setAccessibleName("NextComment");

        jCheckBox1.setText("jCheckBox1");
        jCheckBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox1ItemStateChanged(evt);
            }
        });
        getContentPane().add(jCheckBox1);
        jCheckBox1.setBounds(100, 210, 560, 23);

        jCheckBox2.setText("jCheckBox1");
        getContentPane().add(jCheckBox2);
        jCheckBox2.setBounds(100, 240, 560, 23);

        jCheckBox3.setText("jCheckBox1");
        getContentPane().add(jCheckBox3);
        jCheckBox3.setBounds(100, 270, 560, 23);

        jCheckBox4.setText("jCheckBox1");
        getContentPane().add(jCheckBox4);
        jCheckBox4.setBounds(100, 300, 560, 23);

        jCheckBox5.setText("jCheckBox1");
        getContentPane().add(jCheckBox5);
        jCheckBox5.setBounds(100, 330, 560, 23);

        jCheckBox6.setText("jCheckBox1");
        getContentPane().add(jCheckBox6);
        jCheckBox6.setBounds(100, 360, 560, 20);

        jCheckBox7.setText("jCheckBox1");
        getContentPane().add(jCheckBox7);
        jCheckBox7.setBounds(100, 390, 560, 23);

        CommentArea.setColumns(20);
        CommentArea.setRows(5);
        jScrollPane1.setViewportView(CommentArea);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(50, 60, 660, 130);

        jLabel1.setText("Comment");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(50, 34, 80, 20);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCheckBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox1ItemStateChanged
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_jCheckBox1ItemStateChanged

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    int [] checkBoxes = new int[7];    
       checkBoxes[0] = (this.jCheckBox1.isSelected() == true ? 1 : 0);
       checkBoxes[1] = (this.jCheckBox2.isSelected() == true ? 1 : 0);
       checkBoxes[2] = (this.jCheckBox3.isSelected() == true ? 1 : 0);
       checkBoxes[3] = (this.jCheckBox4.isSelected() == true ? 1 : 0);
       checkBoxes[4] = (this.jCheckBox5.isSelected() == true ? 1 : 0);
       checkBoxes[5] = (this.jCheckBox6.isSelected() == true ? 1 : 0);
       checkBoxes[6] = (this.jCheckBox7.isSelected() == true ? 1 : 0);
        for(int i = 0 ; i < 7 ; i++)
        {
            System.out.println(checkBoxes[i]+" ");
        }       
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterFace().setVisible(true);
            }
        });
    }
    
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (event.getSource() == jButton3)
                {
                    
                }
            }

        };
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea CommentArea;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
    
}
